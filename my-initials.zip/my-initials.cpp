// my-initials.cpp
// Edited by: PUT YOUR NAME HERE, and DATE
//
// A program that draws my initials on the screen
// Press any key to quit.

#include "graphics.h"

int main()
{

	// Open a graphics window size 800 pixels wide x 600 pixels high
	initwindow(800, 600);

	// See "Graphics Functions Examples" on Canvas for list 
	// of functions to use

	// Here are two examples. Erase these and make your own
	// It may be helpful to draw it on paper first

	setcolor(LIGHTGREEN); //outline color
	setfillstyle(SOLID_FILL, LIGHTGREEN); //inside color
	bar(220, 200, 240, 550);

	setcolor(YELLOW);
	setfillstyle(SOLID_FILL, YELLOW);
	pieslice(350, 460, 0, 90, 40);













	getch(); //Wait for a key. (When main function ends, the window will close)
	closegraph(); // shut down the graphics window
	return 0;
} // end main()




